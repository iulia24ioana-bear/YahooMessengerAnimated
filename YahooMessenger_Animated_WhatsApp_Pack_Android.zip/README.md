# Yahoo Messenger Classics – Animated

Pachet Android cu 20 de stickere animate WebP, inspirate de emoticoanele clasice Yahoo Messenger, inclusiv emoticonul de fluierat din imaginea de referință.

## Instalare
1. Deschide folderul în Android Studio.
2. Lasă Gradle să facă sync.
3. Rulează aplicația pe telefon.
4. Apasă „Adaugă pachetul în WhatsApp”.
5. Confirmă în WhatsApp.

Notă: este o recreare neoficială; nu este produs Yahoo sau WhatsApp.
