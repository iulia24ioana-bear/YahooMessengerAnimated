package com.yahoo.classicstickers;
import android.app.*; import android.os.*; import android.content.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(32,60,32,32);
  TextView t=new TextView(this); t.setText("Yahoo Classics Animated\n\n20 emoticoane animate inspirate de Yahoo Messenger."); t.setTextSize(20);
  Button x=new Button(this); x.setText("Adaugă pachetul în WhatsApp");
  x.setOnClickListener(v->{Intent i=new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
   i.putExtra("sticker_pack_id","yahoo_classics_animated"); i.putExtra("sticker_pack_authority","com.yahoo.classicstickers.stickercontentprovider"); i.putExtra("sticker_pack_name","Yahoo Classics Animated");
   try{startActivityForResult(i,200);}catch(Exception e){Toast.makeText(this,"Instalează sau actualizează WhatsApp.",Toast.LENGTH_LONG).show();}});
  l.addView(t,new LinearLayout.LayoutParams(-1,0,1)); l.addView(x); setContentView(l);
 }
}