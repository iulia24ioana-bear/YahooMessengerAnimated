package com.yahoo.classicstickers;
import android.content.*; import android.content.res.*; import android.database.*; import android.database.MatrixCursor; import android.net.*; import java.io.*;
public class StickerContentProvider extends ContentProvider {
 static final String PACK="yahoo_classics_animated", ROOT="1";
 final String[] files={"whistle.webp","happy.webp","laugh.webp","excited.webp","cool.webp","love.webp","kiss.webp","cry.webp","party.webp","sparkle.webp","angry.webp","surprised.webp","sway.webp","nod.webp","wiggle.webp","bounce2.webp","shake2.webp","zoom2.webp","sleep.webp","wink.webp"};
 public boolean onCreate(){return true;}
 public Cursor query(Uri u,String[] p,String s,String[] a,String sort){
  String path=u.getPath(); if(path==null)return null;
  if(path.equals("/metadata")||path.equals("/metadata/"+PACK)){MatrixCursor c=new MatrixCursor(new String[]{"identifier","name","publisher","tray_image_file","image_data_version","animated_sticker_pack"}); c.addRow(new Object[]{PACK,"Yahoo Classics Animated","Classic Chat Stickers","tray.png","1",true}); return c;}
  if(path.equals("/stickers/"+PACK)){MatrixCursor c=new MatrixCursor(new String[]{"sticker_file_name","emojis","accessibility_text"}); for(String f:files)c.addRow(new Object[]{f,"[\"😀\"]",f}); return c;}
  return null;
 }
 public AssetFileDescriptor openAssetFile(Uri u,String mode)throws FileNotFoundException{
  String path=u.getPath(); String pre="/stickers_asset/"+PACK+"/";
  try{if(path!=null&&path.startsWith(pre))return getContext().getAssets().openFd(ROOT+"/"+path.substring(pre.length()));
      if(path!=null&&path.equals("/metadata/"+PACK+"/tray.png"))return getContext().getAssets().openFd(ROOT+"/tray.png");}
  catch(IOException e){throw new FileNotFoundException(path);}
  throw new FileNotFoundException(path);
 }
 public String getType(Uri u){return "image/webp";} public int delete(Uri u,String s,String[] a){return 0;} public int update(Uri u,ContentValues v,String s,String[] a){return 0;} public Uri insert(Uri u,ContentValues v){return null;}
}