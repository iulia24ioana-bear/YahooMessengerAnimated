# Yahoo Messenger Classics

Android sticker app for WhatsApp using the official third-party sticker app model.

- 18 animated stickers in one pack
- 2 static stickers in a separate pack (WhatsApp requires a pack to be either fully animated or fully static)
- 512x512 WebP sticker assets
- GitHub Actions builds a debug APK

Build artifact: `app-debug.apk`
