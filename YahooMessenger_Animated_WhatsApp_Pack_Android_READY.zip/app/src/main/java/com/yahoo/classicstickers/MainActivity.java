package com.yahoo.classicstickers;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.*;

public class MainActivity extends Activity {
    private void addPack(String id, String name) {
        Intent i = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
        i.putExtra("sticker_pack_id", id);
        i.putExtra("sticker_pack_authority", "com.yahoo.classicstickers.stickercontentprovider");
        i.putExtra("sticker_pack_name", name);
        try { startActivityForResult(i, 200); }
        catch (Exception e) { Toast.makeText(this, "Instalează sau actualizează WhatsApp.", Toast.LENGTH_LONG).show(); }
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(32,60,32,32);
        TextView t = new TextView(this); t.setText("Yahoo Messenger Classics\n\n18 emoticoane animate + 2 statice."); t.setTextSize(20);
        Button a = new Button(this); a.setText("Adaugă emoticoanele animate"); a.setOnClickListener(v -> addPack("yahoo_classics_animated", "Yahoo Classics Animated"));
        Button s = new Button(this); s.setText("Adaugă emoticoanele statice"); s.setOnClickListener(v -> addPack("yahoo_classics_static", "Yahoo Classics Static"));
        l.addView(t, new LinearLayout.LayoutParams(-1,0,1)); l.addView(a); l.addView(s); setContentView(l);
    }
}
