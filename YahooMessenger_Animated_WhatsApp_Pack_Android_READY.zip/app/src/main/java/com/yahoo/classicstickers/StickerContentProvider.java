package com.yahoo.classicstickers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import java.io.FileNotFoundException;
import java.io.IOException;

public class StickerContentProvider extends ContentProvider {
    private static final String ROOT = "1";
    private static final String ANIMATED = "yahoo_classics_animated";
    private static final String STATIC = "yahoo_classics_static";
    private static final String[] ANIMATED_FILES = {
        "whistle.webp","happy.webp","laugh.webp","excited.webp","love.webp","kiss.webp",
        "cry.webp","party.webp","sparkle.webp","surprised.webp","sway.webp","nod.webp",
        "wiggle.webp","bounce2.webp","shake2.webp","zoom2.webp","sleep.webp","wink.webp"
    };
    private static final String[] STATIC_FILES = {"angry.webp","cool.webp"};

    @Override public boolean onCreate() { return true; }

    private MatrixCursor metadataCursor() {
        MatrixCursor c = new MatrixCursor(new String[]{
            "sticker_pack_identifier","sticker_pack_name","sticker_pack_publisher","sticker_pack_icon",
            "android_play_store_link","ios_app_store_link","publisher_email","publisher_website",
            "privacy_policy_website","license_agreement_website","image_data_version","avoid_cache",
            "animated_sticker_pack"
        });
        c.addRow(new Object[]{ANIMATED,"Yahoo Classics Animated","Classic Chat Stickers","tray.png","","","","","","","2",0,1});
        c.addRow(new Object[]{STATIC,"Yahoo Classics Static","Classic Chat Stickers","tray_static.png","","","","","","","1",0,0});
        return c;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        String path = uri.getPath();
        if (path == null) return null;
        if (path.equals("/metadata") || path.equals("/metadata/" + ANIMATED) || path.equals("/metadata/" + STATIC)) {
            return metadataCursor();
        }
        if (path.equals("/stickers/" + ANIMATED) || path.equals("/stickers/" + STATIC)) {
            boolean isAnimated = path.endsWith(ANIMATED);
            String[] files = isAnimated ? ANIMATED_FILES : STATIC_FILES;
            MatrixCursor c = new MatrixCursor(new String[]{"sticker_file_name","sticker_emoji","sticker_accessibility_text"});
            for (String f : files) {
                String emoji = f.equals("angry.webp") ? "[\"😠\"]" : f.equals("cool.webp") ? "[\"😎\"]" : "[\"😀\"]";
                c.addRow(new Object[]{f, emoji, f.replace(".webp", "")});
            }
            return c;
        }
        return null;
    }

    @Override
    public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws FileNotFoundException {
        String path = uri.getPath();
        String prefixA = "/stickers_asset/" + ANIMATED + "/";
        String prefixS = "/stickers_asset/" + STATIC + "/";
        try {
            if (path != null && path.startsWith(prefixA)) return getContext().getAssets().openFd(ROOT + "/" + path.substring(prefixA.length()));
            if (path != null && path.startsWith(prefixS)) return getContext().getAssets().openFd(ROOT + "/" + path.substring(prefixS.length()));
            if (path != null && path.equals("/metadata/" + ANIMATED + "/tray.png")) return getContext().getAssets().openFd(ROOT + "/tray.png");
            if (path != null && path.equals("/metadata/" + STATIC + "/tray_static.png")) return getContext().getAssets().openFd(ROOT + "/tray_static.png");
        } catch (IOException e) { throw new FileNotFoundException(path); }
        throw new FileNotFoundException(path);
    }

    @Override public String getType(Uri uri) { return "image/webp"; }
    @Override public int delete(Uri uri, String selection, String[] args) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { return 0; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
}
